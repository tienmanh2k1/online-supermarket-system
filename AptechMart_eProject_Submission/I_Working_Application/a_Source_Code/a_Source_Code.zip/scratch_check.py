import sys

try:
    import openpyxl
    print("OPENPYXL_AVAILABLE")
except ImportError:
    print("OPENPYXL_NOT_AVAILABLE")
